# Librespot for Kodi — Raspberry Pi OS Lite edition (no PulseAudio)

A port of awiouy's LibreELEC Librespot add-on for Kodi on **Raspberry Pi OS
Lite** (armhf or arm64). The OSMC build's private PulseAudio daemon is gone;
its null-sink + module-rtp-send pair is replaced by librespot's pipe backend
feeding ffmpeg, which produces the identical local RTP stream (L16/44100/2,
payload type 10) that Kodi played before.

## Output modes

**kodi (default)** — Spotify plays *inside* Kodi with artwork, metadata,
seek and the usual now-playing screen:

    librespot --backend pipe → FIFO → ffmpeg → rtp://127.0.0.1:23432 → Kodi

Kodi is the only process that touches the ALSA device, so there is no
device contention at all. A keeper file descriptor holds the FIFO open so
ffmpeg survives librespot opening and closing its end between sessions.

**alsa** — librespot writes straight to the sound card and Kodi only shows
track-change notifications. Set the ALSA device to anything `aplay -L`
lists. In this mode enable **Do not disturb Kodi** (stops librespot while
Kodi plays) unless your device mixes via dmix, and consider turning off
Kodi's *Keep audio device alive* setting.

## What the one-shot installer does

On first service start, `resources/install/install-root.sh` runs via
`sudo -n` (Raspberry Pi OS grants the first user passwordless sudo by
default) and:

- installs runtime deps (ffmpeg, python3-pil, alsa-utils),
- installs Rust 1.89.0 for your architecture and builds librespot v0.8.0
  (commit-pinned) with `--no-default-features --features 'alsa-backend
  native-tls'` — the pipe backend is always built in,
- installs `/usr/local/bin/librespot-frankie`,
- adds the Kodi user to the `audio` group if needed,
- writes `/var/lib/frankie-librespot/installed-0.8.0-alsa-r2`.

Reruns skip compilation if a 0.8.0 binary is already installed. Zeroconf
uses librespot's built-in libmdns — no avahi, no systemd units, and nothing
runs as root after installation. Compilation takes roughly 20–40 minutes on
a Pi 4; the log is `/tmp/frankie-librespot-install.log`.

## Requirements

- Spotify Premium account (Spotify Connect requirement)
- Internet access during first installation
- Kodi running as a normal user on Raspberry Pi OS Lite (Bullseye/Bookworm)

## Uninstall

Remove the add-on in Kodi, then over SSH:

    sudo rm -f /usr/local/bin/librespot-frankie
    sudo rm -rf /var/lib/frankie-librespot
