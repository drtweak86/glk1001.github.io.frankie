import fcntl
import os
import subprocess

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
INSTALLER = os.path.join(ADDON_PATH, "resources", "install", "install-root.sh")
BINARY = "/usr/local/bin/librespot-frankie"
FFMPEG = "/usr/bin/ffmpeg"
MARKER = "/var/lib/frankie-librespot/installed-0.8.0-alsa-r2"
LOCKFILE = os.path.join(PROFILE, "service.lock")


def _log(message, level=xbmc.LOGINFO):
    xbmc.log("Librespot: {}".format(message), level)


def _set_status(value):
    try:
        ADDON.setSetting("installer_status", value)
    except Exception:
        pass


def _ready():
    return (
        os.path.isfile(BINARY)
        and os.access(BINARY, os.X_OK)
        and os.path.isfile(FFMPEG)
        and os.path.isfile(MARKER)
    )


def _acquire_lock():
    os.makedirs(PROFILE, exist_ok=True)
    handle = open(LOCKFILE, "w", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        handle.close()
        return None
    return handle


def _install():
    progress = xbmcgui.DialogProgressBG()
    progress.create("Librespot for Frankie", "Preparing one-shot installation…")
    _set_status("Installing")

    command = ["sudo", "-n", "/bin/bash", INSTALLER, ADDON_PATH]
    _log("Running installer: {}".format(" ".join(command)))

    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except Exception as exc:
        progress.close()
        _set_status("Installer could not start")
        xbmcgui.Dialog().ok("Librespot", "Could not start the installer:\n{}".format(exc))
        return False

    last_message = "Installing…"
    try:
        assert process.stdout is not None
        for raw_line in process.stdout:
            line = raw_line.rstrip()
            if not line:
                continue
            _log("installer: {}".format(line))
            if line.startswith("@@"):
                try:
                    _, percent, message = line.split("@@", 2)
                    last_message = message
                    progress.update(max(0, min(100, int(percent))), message)
                except Exception:
                    progress.update(0, line)
            else:
                progress.update(0, last_message)
        returncode = process.wait()
    finally:
        progress.close()

    if returncode != 0:
        _set_status("Installation failed")
        if returncode == 77:
            detail = (
                "Kodi could not use passwordless sudo. Raspberry Pi OS normally "
                "permits this for the first user. Alternatively run once over SSH:\n"
                "sudo /bin/bash {} {}".format(INSTALLER, ADDON_PATH)
            )
        else:
            detail = (
                "Installer exited with code {}. "
                "See /tmp/frankie-librespot-install.log.".format(returncode)
            )
        xbmcgui.Dialog().ok("Librespot installation failed", detail)
        return False

    if _ready():
        _set_status("Installed and running")
        xbmcgui.Dialog().notification(
            "Librespot",
            "Frankie is now available in Spotify Connect",
            ADDON.getAddonInfo("icon"),
            8000,
        )
        return True

    _set_status("Installed; binary missing")
    xbmcgui.Dialog().ok(
        "Librespot",
        "Installation completed, but the librespot binary is missing. "
        "See /tmp/frankie-librespot-install.log.",
    )
    return False


def run_service():
    lock_handle = _acquire_lock()
    if lock_handle is None:
        _log("Another Librespot service instance is already active")
        return

    try:
        if not _ready() and not _install():
            return

        _set_status("Installed and running")
        import monitor

        monitor.run()
    except Exception as exc:
        _log("Service failed: {!r}".format(exc), xbmc.LOGERROR)
        _set_status("Runtime error")
        xbmcgui.Dialog().notification(
            "Librespot error",
            str(exc),
            ADDON.getAddonInfo("icon"),
            10000,
        )
    finally:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
            lock_handle.close()
        except Exception:
            pass


def open_settings():
    if _ready():
        _set_status("Installed and running")
    else:
        _set_status("Installation pending")
    ADDON.openSettings()
