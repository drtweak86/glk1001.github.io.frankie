import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_ADDON = xbmcaddon.Addon()
_ADDON_HOME = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_ADDON_ICON = _ADDON.getAddonInfo("icon")
_ADDON_NAME = _ADDON.getAddonInfo("name")
_ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo("path"))
_DIALOG = xbmcgui.Dialog()
_SETTINGS = {
    "alsa_device": "default",
    "backend": "kodi",
    "dnd_kodi": "false",
    "name": "Frankie",
    "player": "default",
    "zeroconf_fixed": "false",
    "zeroconf_port": "50252",
}

ADDON_HOME = _ADDON_HOME
LIBRESPOT_BINARY = "/usr/local/bin/librespot-frankie"
os.makedirs(_ADDON_HOME, exist_ok=True)
os.chdir(_ADDON_HOME)


def get_setting(key):
    setting = _ADDON.getSetting(key)
    return setting if setting else _SETTINGS[key]


def setting_is_true(key):
    return get_setting(key).lower() == "true"


def log(message, notify=False):
    xbmc.log("{}: {}".format(_ADDON_NAME, message), xbmc.LOGINFO)
    if notify:
        notification(message)


def logged_method(method):
    def logger(*args, **kwargs):
        log("{}.{}".format(method.__module__, method.__qualname__))
        return method(*args, **kwargs)

    return logger


def call_if_has(target, method_name, *args, **kwargs):
    method = getattr(target, method_name, None)
    if callable(method):
        return method(*args, **kwargs)
    return None


def notification(message="", heading=_ADDON_NAME, icon=_ADDON_ICON, sound=False, time=5000):
    _DIALOG.notification(heading, message, icon, time, sound)


def set_inputstream_if_available(list_item):
    try:
        xbmcaddon.Addon("inputstream.ffmpeg")
        list_item.setProperty("inputstream", "inputstream.ffmpeg")
        log("Using inputstream.ffmpeg")
    except Exception:
        # Kodi can hand RTP directly to its internal FFmpeg player.
        log("inputstream.ffmpeg is not installed; using Kodi's native RTP handling")
