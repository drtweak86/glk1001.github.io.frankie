import xbmc

import service
import service_kodi
import utils


def _get_service():
    while True:
        zeroconf_port = "0"
        if utils.setting_is_true("zeroconf_fixed"):
            zeroconf_port = utils.get_setting("zeroconf_port")

        if utils.get_setting("backend") == "alsa":
            service_ = service.Service(
                "alsa", utils.get_setting("alsa_device"), zeroconf_port
            )
        else:
            service_ = service_kodi.Service(zeroconf_port)
        yield from service_.run()


class _Monitor(xbmc.Monitor):
    @utils.logged_method
    def __init__(self):
        super().__init__()
        self._service = _get_service()
        next(self._service)

    @utils.logged_method
    def onSettingsChanged(self):
        try:
            next(self._service)
        except StopIteration:
            self._service = _get_service()
            next(self._service)

    def close(self):
        try:
            self._service.close()
        except Exception:
            pass


def run():
    monitor = _Monitor()
    try:
        monitor.waitForAbort()
    finally:
        monitor.close()
