#!/bin/bash
# One-shot root installer for the Librespot Kodi add-on on Raspberry Pi OS
# (Lite), ALSA edition. Builds librespot 0.8.0 with only the ALSA + pipe
# backends and built-in libmdns zeroconf discovery. Playback inside Kodi is
# provided by ffmpeg re-wrapping librespot's pipe output as local RTP — no
# PulseAudio and no extra systemd services. Reruns skip compilation when a
# matching binary is already installed.
set -Eeuo pipefail

LOG=/tmp/frankie-librespot-install.log
exec > >(tee -a "$LOG") 2>&1

progress() {
    printf '@@%s@@%s\n' "$1" "$2"
}

fail() {
    echo "ERROR: $*"
    exit 1
}

trap 'echo "ERROR at line $LINENO: $BASH_COMMAND"' ERR

[ "$(id -u)" -eq 0 ] || exit 77
[ $# -eq 1 ] || fail "Expected add-on path"
ADDON_PATH=$1
[ -d "$ADDON_PATH" ] || fail "Add-on path not found: $ADDON_PATH"

BINARY=/usr/local/bin/librespot-frankie
EXPECTED_COMMIT="d36f9f1907e8cc9d68a93f8ebc6b627b1bf7267d"

TARGET_USER=${SUDO_USER:-}
if [ -z "$TARGET_USER" ] || ! id "$TARGET_USER" >/dev/null 2>&1; then
    TARGET_USER=$(getent passwd 1000 | cut -d: -f1)
fi
[ -n "$TARGET_USER" ] || fail "Could not determine the user that runs Kodi"
TARGET_HOME=$(getent passwd "$TARGET_USER" | cut -d: -f6)
[ -n "$TARGET_HOME" ] || fail "No home directory for $TARGET_USER"
TARGET_GROUP=$(id -gn "$TARGET_USER")

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

progress 2 "Checking Frankie's architecture"
DPKG_ARCH=$(dpkg --print-architecture)
case "$DPKG_ARCH" in
    armhf)
        RUST_TRIPLE=armv7-unknown-linux-gnueabihf
        ;;
    arm64)
        RUST_TRIPLE=aarch64-unknown-linux-gnu
        ;;
    *)
        fail "Unsupported architecture: $DPKG_ARCH (expected armhf or arm64 Raspberry Pi OS)"
        ;;
esac
echo "Architecture: $DPKG_ARCH -> $RUST_TRIPLE"

progress 4 "Making sure $TARGET_USER can use ALSA"
if ! id -nG "$TARGET_USER" | tr ' ' '\n' | grep -qx audio; then
    usermod -aG audio "$TARGET_USER"
    echo "Added $TARGET_USER to the audio group (takes effect after re-login/reboot)"
fi

progress 6 "Updating package lists"
apt-get update

progress 10 "Installing runtime dependencies (ffmpeg for the Kodi RTP bridge)"
apt-get install -y --no-install-recommends \
    ca-certificates ffmpeg python3-pil alsa-utils

NEED_BUILD=1
if [ -x "$BINARY" ] && "$BINARY" --version 2>/dev/null | grep -q '0\.8\.0'; then
    echo "Existing librespot 0.8.0 binary found; skipping compilation"
    NEED_BUILD=0
fi

if [ "$NEED_BUILD" -eq 1 ]; then
    progress 14 "Installing build dependencies"
    apt-get install -y --no-install-recommends \
        curl git build-essential pkg-config cmake clang libclang-dev \
        protobuf-compiler libssl-dev libasound2-dev

    progress 20 "Installing the Rust compiler for $RUST_TRIPLE"
    RUSTUP_INIT=/tmp/rustup-init-frankie
    curl --proto '=https' --tlsv1.2 -fL \
        "https://static.rust-lang.org/rustup/dist/${RUST_TRIPLE}/rustup-init" \
        -o "$RUSTUP_INIT"
    chmod 755 "$RUSTUP_INIT"

    sudo -u "$TARGET_USER" env \
        HOME="$TARGET_HOME" \
        CARGO_HOME="$TARGET_HOME/.cargo" \
        RUSTUP_HOME="$TARGET_HOME/.rustup" \
        "$RUSTUP_INIT" -y --profile minimal --default-toolchain 1.89.0 --no-modify-path

    CARGO="$TARGET_HOME/.cargo/bin/cargo"
    RUSTC="$TARGET_HOME/.cargo/bin/rustc"
    [ -x "$CARGO" ] || fail "Cargo was not installed"

    HOST=$(
        sudo -u "$TARGET_USER" env HOME="$TARGET_HOME" \
            CARGO_HOME="$TARGET_HOME/.cargo" RUSTUP_HOME="$TARGET_HOME/.rustup" \
            "$RUSTC" -vV | awk '/^host:/ {print $2}'
    )
    [ "$HOST" = "$RUST_TRIPLE" ] || fail "Rust host is $HOST, expected $RUST_TRIPLE"

    progress 28 "Downloading librespot 0.8.0"
    BUILD_ROOT="$TARGET_HOME/.cache/frankie-librespot-build"
    rm -rf "$BUILD_ROOT"
    install -d -o "$TARGET_USER" -g "$TARGET_GROUP" "$BUILD_ROOT"

    sudo -u "$TARGET_USER" env HOME="$TARGET_HOME" git clone \
        --depth 1 --branch v0.8.0 \
        https://github.com/librespot-org/librespot.git "$BUILD_ROOT/librespot"

    COMMIT=$(sudo -u "$TARGET_USER" git -C "$BUILD_ROOT/librespot" rev-parse HEAD)
    [ "$COMMIT" = "$EXPECTED_COMMIT" ] || fail "Unexpected librespot v0.8.0 commit: $COMMIT"

    progress 35 "Compiling librespot (ALSA + pipe) — this is the slow part"
    sudo -u "$TARGET_USER" env \
        HOME="$TARGET_HOME" \
        CARGO_HOME="$TARGET_HOME/.cargo" \
        RUSTUP_HOME="$TARGET_HOME/.rustup" \
        CARGO_BUILD_JOBS=4 \
        nice -n 5 "$CARGO" build \
            --manifest-path "$BUILD_ROOT/librespot/Cargo.toml" \
            --release --locked --no-default-features \
            --features 'alsa-backend native-tls'

    BUILT="$BUILD_ROOT/librespot/target/release/librespot"
    [ -x "$BUILT" ] || fail "Compiled librespot binary was not produced"

    progress 82 "Installing the librespot binary"
    install -m 755 "$BUILT" "$BINARY"
    strip "$BINARY" || true
fi

"$BINARY" --version
if ldd "$BINARY" | grep -q 'not found'; then
    ldd "$BINARY"
    fail "The librespot binary has missing shared libraries"
fi

progress 90 "Checking the ALSA device list"
sudo -u "$TARGET_USER" aplay -L | head -n 20 || true

progress 94 "Writing installation marker"
install -d -m 755 /var/lib/frankie-librespot
cat > /var/lib/frankie-librespot/installed-0.8.0-alsa-r2 <<EOF
librespot=0.8.0
commit=$EXPECTED_COMMIT
architecture=$DPKG_ARCH
backends=pipe+alsa
kodi_bridge=ffmpeg-rtp
installed=$(date --iso-8601=seconds)
addon=$ADDON_PATH
EOF
chmod 644 /var/lib/frankie-librespot/installed-0.8.0-alsa-r2

progress 97 "Cleaning temporary build files"
rm -rf "${BUILD_ROOT:-}" "${RUSTUP_INIT:-}" 2>/dev/null || true

progress 100 "Librespot is installed — Frankie is joining Spotify Connect"
echo "Installation complete"
