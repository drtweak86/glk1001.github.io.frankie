import os
import sys

LIB = os.path.join(os.path.dirname(__file__), "resources", "lib")
if LIB not in sys.path:
    sys.path.insert(0, LIB)

import bootstrap

bootstrap.run_service()
